import { Component, OnInit } from '@angular/core';
import { SesionesService } from 'src/app/services/sesiones.service';
import { JuegosService } from 'src/app/services/juegos.service';
import { Juego } from 'src/app/interfaces/juegos.interface';
import { forkJoin } from 'rxjs';
import { AuthService } from 'src/app/services/auth.service';
import Swal from 'sweetalert2';
import { Router } from '@angular/router';

@Component({
  selector: 'app-mis-sesiones',
  templateUrl: './mis-sesiones.component.html',
  styleUrls: ['./mis-sesiones.component.css']
})
export class MisSesionesComponent implements OnInit {
  sessions: any[] = [];
  totalPoints: number = 0;
  juegos: Juego[] = [];
  totalSessions: number = 0;
  pageSize: number = 5; // Número de sesiones por página
  currentPage: number = 1; // Página actual
  totalPages: number = 0; // Total de páginas
  paginatedSessions: any[] = []; // Sesiones que se muestran en la página actual

  constructor(
    private sesionesService: SesionesService,
    private juegosService: JuegosService,
    private authService: AuthService,
    private router: Router
  ) {}

  ngOnInit(): void {
    if (!this.authService.isAuthenticated()) {
      Swal.fire({
        title: 'No has iniciado sesión',
        text: 'Para ver tus sesiones, debes iniciar sesión o registrarte.',
        icon: 'warning',
        showCancelButton: true,
        confirmButtonText: 'Ir a Iniciar Sesión',
        cancelButtonText: 'Registrarse',
        confirmButtonColor: '#28a745',
        cancelButtonColor: '#007bff'
      }).then((result) => {
        if (result.isConfirmed) {
          this.router.navigate(['/login']);
        } else if (result.isDismissed) {
          this.router.navigate(['/register']);
        }
      });
    } else {
      this.getSessions(); // Obtener las sesiones si está autenticado
    }
  }

  getSessions(): void {
    forkJoin({
      sessions: this.sesionesService.getMySessions(),
      juegos: this.juegosService.getAllJuegos()
    }).subscribe(
      ({ sessions, juegos }) => {
        this.sessions = sessions.sessions;
        this.juegos = juegos;

        // Mapeamos las sesiones para agregar el nombre del juego
        this.sessions = this.sessions.map(session => ({
          ...session,
          gameName: this.getNombreJuego(session.game_id) // Agregamos dinámicamente el nombre del juego
        }));

        // Actualizamos los puntos totales
        this.totalPoints = sessions['Puntos totales'];
        this.totalSessions = this.sessions.length; // Número total de sesiones

        // Calculamos el número total de páginas
        this.totalPages = Math.ceil(this.totalSessions / this.pageSize);
        
        // Actualizamos las sesiones de la página actual
        this.updatePaginatedSessions();
      },
      (error) => {
        console.error('Error al obtener las sesiones', error);
      }
    );
  }

  // Método para obtener el nombre del juego a partir del game_id
  getNombreJuego(game_id: number): string {
    const juego = this.juegos.find(e => e.id === game_id);
    return juego ? juego.name : 'Desconocido'; // Si no encontramos el juego, retornamos 'Desconocido'
  }

  // Actualizamos las sesiones a mostrar según la página actual
  updatePaginatedSessions(): void {
    const startIndex = (this.currentPage - 1) * this.pageSize;
    const endIndex = startIndex + this.pageSize;
    this.paginatedSessions = this.sessions.slice(startIndex, endIndex);
  }

  // Método para cambiar a la página anterior
  previousPage(): void {
    if (this.currentPage > 1) {
      this.currentPage--;
      this.updatePaginatedSessions();
    }
  }

  // Método para cambiar a la siguiente página
  nextPage(): void {
    if (this.currentPage < this.totalPages) {
      this.currentPage++;
      this.updatePaginatedSessions();
    }
  }
}

import { Component } from '@angular/core';
import { AuthService } from 'src/app/services/auth.service';
import { Router } from '@angular/router';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent {
  name = '';
  email = '';
  password = '';
  password_confirmation = '';

  constructor(private authService: AuthService, private router: Router) {}

  onRegister() {
    if (this.password !== this.password_confirmation) {
      Swal.fire({
        title: 'Error',
        text: 'Las contraseñas no coinciden.',
        icon: 'error',
        confirmButtonText: 'Aceptar'
      });
      return;
    }

    this.authService.register(this.name, this.email, this.password, this.password_confirmation)
      .subscribe({
        next: () => {
          Swal.fire({
            title: 'Registro Exitoso',
            text: 'Tu cuenta ha sido creada correctamente.',
            icon: 'success',
            confirmButtonText: 'Aceptar'
          }).then(() => {
            this.router.navigate(['/juegos']); // Redirigir después del registro
          });
        },
        error: (err) => {
          Swal.fire({
            title: 'Error en el Registro',
            text: err.error.message || 'Ocurrió un error al registrarse.',
            icon: 'error',
            confirmButtonText: 'Intentar de nuevo'
          });
        }
      });
  }
}
